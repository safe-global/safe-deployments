### Audit Results

##### Auditor

-   Certora (https://www.certora.com/)

##### Notes

The final audit was performed on commit [1c8b24a0a438e8c2cd089a9d830d1688a47a28d5](https://github.com/safe-global/safe-smart-account/tree/1c8b24a0a438e8c2cd089a9d830d1688a47a28d5).

There has been few bugfixes and gas optimization based changes.

##### Files

-   [Final Audit Report 1.5.0](Safe_Audit_Report_1_5_0.pdf)
